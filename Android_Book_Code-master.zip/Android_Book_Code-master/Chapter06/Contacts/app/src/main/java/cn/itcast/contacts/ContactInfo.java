package cn.itcast.contacts;
public class ContactInfo {
    private String contactName;   //联系人名称
    private String phoneNumber;   //电话号码
    public String getContactName() {
        return contactName;
    }
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
