package com.example.photoduplicatecleaner.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.model.Photo;
import com.example.photoduplicatecleaner.model.PhotoGroup;
import com.example.photoduplicatecleaner.viewmodel.MainViewModel;
import com.github.chrisbanes.photoview.PhotoView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 图片查看界面，显示大图并允许用户选择删除或保留
 */
public class ImageViewActivity extends AppCompatActivity {

    private MainViewModel viewModel;
    private PhotoView photoView;
    private TextView tvPhotoInfo;
    private TextView tvCounter;
    private CheckBox cbSelectForDeletion;
    private Button btnKeepThis;
    private Toolbar toolbar;

    private PhotoGroup currentGroup;
    private List<Photo> photos;
    private int currentPosition = 0;
    private String groupId;
    private String photoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);

        // 获取组ID和照片ID
        groupId = getIntent().getStringExtra("GROUP_ID");
        photoId = getIntent().getStringExtra("PHOTO_ID");
        if (groupId == null) {
            finish();
            return;
        }

        // 初始化视图
        photoView = findViewById(R.id.photoView);
        tvPhotoInfo = findViewById(R.id.tvPhotoInfo);
        tvCounter = findViewById(R.id.tvCounter);
        cbSelectForDeletion = findViewById(R.id.cbSelectForDeletion);
        btnKeepThis = findViewById(R.id.btnKeepThis);
        toolbar = findViewById(R.id.toolbar);

        // 设置工具栏
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // 设置工具栏导航点击监听器
        toolbar.setNavigationOnClickListener(v -> finish());

        // 获取ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // 设置选择框点击监听器
        cbSelectForDeletion.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (currentGroup != null && currentPosition < photos.size()) {
                Photo photo = photos.get(currentPosition);
                if (isChecked) {
                    currentGroup.selectForDeletion(photo);
                } else {
                    currentGroup.unselectForDeletion(photo);
                }
            }
        });

        // 设置保留按钮点击监听器
        btnKeepThis.setOnClickListener(v -> {
            if (currentGroup != null && currentPosition < photos.size()) {
                Photo photo = photos.get(currentPosition);
                viewModel.selectAllExcept(currentGroup, photo);
                updateUI();
                Toast.makeText(this, "已选择除此照片外的所有照片", Toast.LENGTH_SHORT).show();
            }
        });

        // 设置照片点击监听器（切换控制栏显示/隐藏）
        photoView.setOnClickListener(v -> {
            View controls = findViewById(R.id.layoutControls);
            if (controls.getVisibility() == View.VISIBLE) {
                controls.setVisibility(View.GONE);
                toolbar.setVisibility(View.GONE);
            } else {
                controls.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
            }
        });

        // 加载照片
        loadPhotos();
    }

    /**
     * 加载照片组和当前照片
     */
    private void loadPhotos() {
        List<PhotoGroup> groups = viewModel.getCachedResults();
        for (PhotoGroup group : groups) {
            if (group.getId().equals(groupId)) {
                currentGroup = group;
                photos = group.getPhotos();
                break;
            }
        }

        if (currentGroup == null || photos.isEmpty()) {
            finish();
            return;
        }

        // 查找当前照片的位置
        if (photoId != null) {
            for (int i = 0; i < photos.size(); i++) {
                if (photos.get(i).getId().equals(photoId)) {
                    currentPosition = i;
                    break;
                }
            }
        }

        // 显示当前照片
        displayCurrentPhoto();

        // 设置左右滑动切换照片
        photoView.setOnScaleChangeListener((scaleFactor, focusX, focusY) -> {
            // 只有在缩放比例为1时才允许滑动切换
            if (scaleFactor == 1.0f) {
                photoView.setAllowParentInterceptOnEdge(true);
            } else {
                photoView.setAllowParentInterceptOnEdge(false);
            }
        });

        // 设置左右滑动监听器
        View rootView = findViewById(android.R.id.content);
        rootView.setOnTouchListener(new OnSwipeTouchListener(this) {
            @Override
            public void onSwipeLeft() {
                showNextPhoto();
            }

            @Override
            public void onSwipeRight() {
                showPreviousPhoto();
            }
        });
    }

    /**
     * 显示当前照片
     */
    private void displayCurrentPhoto() {
        if (currentPosition < 0 || currentPosition >= photos.size()) {
            return;
        }

        Photo photo = photos.get(currentPosition);

        // 加载照片
        Glide.with(this)
                .load(new File(photo.getPath()))
                .into(photoView);

        // 更新照片信息
        updatePhotoInfo(photo);

        // 更新计数器
        tvCounter.setText(String.format("%d/%d", currentPosition + 1, photos.size()));

        // 更新选择状态
        updateSelectionState(photo);
    }

    /**
     * 更新照片信息
     */
    private void updatePhotoInfo(Photo photo) {
        StringBuilder info = new StringBuilder();
        
        // 添加文件名
        String fileName = new File(photo.getPath()).getName();
        info.append(fileName);
        
        // 添加文件大小
        info.append(" • ").append(photo.getFormattedSize());
        
        // 添加分辨率
        if (photo.getWidth() > 0 && photo.getHeight() > 0) {
            info.append(" • ").append(photo.getWidth()).append("x").append(photo.getHeight());
        }
        
        // 添加修改日期
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        String date = sdf.format(new Date(photo.getDateModified() * 1000));
        info.append(" • ").append(date);
        
        tvPhotoInfo.setText(info.toString());
    }

    /**
     * 更新选择状态
     */
    private void updateSelectionState(Photo photo) {
        boolean isSuggestedKeep = photo.equals(currentGroup.getSuggestedKeepPhoto());
        boolean isSelected = currentGroup.isSelectedForDeletion(photo);
        
        cbSelectForDeletion.setEnabled(!isSuggestedKeep);
        cbSelectForDeletion.setChecked(isSelected);
        
        if (isSuggestedKeep) {
            btnKeepThis.setEnabled(false);
            btnKeepThis.setAlpha(0.5f);
        } else {
            btnKeepThis.setEnabled(true);
            btnKeepThis.setAlpha(1.0f);
        }
    }

    /**
     * 显示下一张照片
     */
    private void showNextPhoto() {
        if (currentPosition < photos.size() - 1) {
            currentPosition++;
            displayCurrentPhoto();
        }
    }

    /**
     * 显示上一张照片
     */
    private void showPreviousPhoto() {
        if (currentPosition > 0) {
            currentPosition--;
            displayCurrentPhoto();
        }
    }

    /**
     * 更新UI
     */
    private void updateUI() {
        if (currentPosition < photos.size()) {
            Photo photo = photos.get(currentPosition);
            updateSelectionState(photo);
        }
    }

    /**
     * 滑动手势监听器
     */
    private static class OnSwipeTouchListener implements View.OnTouchListener {
        private final GestureDetector gestureDetector;

        public OnSwipeTouchListener(Context context) {
            gestureDetector = new GestureDetector(context, new GestureListener());
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            return gestureDetector.onTouchEvent(event);
        }

        private final class GestureListener extends GestureDetector.SimpleOnGestureListener {
            private static final int SWIPE_THRESHOLD = 100;
            private static final int SWIPE_VELOCITY_THRESHOLD = 100;

            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                boolean result = false;
                try {
                    float diffY = e2.getY() - e1.getY();
                    float diffX = e2.getX() - e1.getX();
                    if (Math.abs(diffX) > Math.abs(diffY)) {
                        if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                            if (diffX > 0) {
                                onSwipeRight();
                            } else {
                                onSwipeLeft();
                            }
                            result = true;
                        }
                    }
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
                return result;
            }
        }

        public void onSwipeRight() {
        }

        public void onSwipeLeft() {
        }
    }
}
