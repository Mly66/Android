package com.example.photoduplicatecleaner.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.model.Photo;
import com.example.photoduplicatecleaner.model.PhotoGroup;

/**
 * 照片适配器，用于在分组详情屏幕中显示照片网格
 */
public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder> {

    private PhotoGroup photoGroup;
    private final OnPhotoClickListener listener;

    public interface OnPhotoClickListener {
        void onPhotoClick(Photo photo);
        void onPhotoLongClick(Photo photo);
        void onKeepThisClick(Photo photo);
    }

    public PhotoAdapter(OnPhotoClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        Photo photo = photoGroup.getPhotos().get(position);
        holder.bind(photo);
    }

    @Override
    public int getItemCount() {
        return photoGroup != null ? photoGroup.getPhotoCount() : 0;
    }

    public void setPhotoGroup(PhotoGroup photoGroup) {
        this.photoGroup = photoGroup;
        notifyDataSetChanged();
    }

    class PhotoViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivPhoto;
        private final CheckBox cbSelect;
        private final TextView tvPhotoInfo;
        private final ImageButton btnKeepThis;

        PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPhoto = itemView.findViewById(R.id.ivPhoto);
            cbSelect = itemView.findViewById(R.id.cbSelect);
            tvPhotoInfo = itemView.findViewById(R.id.tvPhotoInfo);
            btnKeepThis = itemView.findViewById(R.id.btnKeepThis);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onPhotoClick(photoGroup.getPhotos().get(position));
                }
            });

            itemView.setOnLongClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onPhotoLongClick(photoGroup.getPhotos().get(position));
                    return true;
                }
                return false;
            });

            cbSelect.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Photo photo = photoGroup.getPhotos().get(position);
                    if (cbSelect.isChecked()) {
                        photoGroup.selectForDeletion(photo);
                    } else {
                        photoGroup.unselectForDeletion(photo);
                    }
                }
            });

            btnKeepThis.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onKeepThisClick(photoGroup.getPhotos().get(position));
                }
            });
        }

        void bind(Photo photo) {
            // 加载照片缩略图
            Glide.with(ivPhoto.getContext())
                    .load(photo.getPath())
                    .placeholder(R.drawable.ic_image_placeholder)
                    .error(R.drawable.ic_image_error)
                    .centerCrop()
                    .into(ivPhoto);

            // 设置照片信息
            String info = photo.getFormattedSize();
            if (photo.getWidth() > 0 && photo.getHeight() > 0) {
                info += " • " + photo.getWidth() + "x" + photo.getHeight();
            }
            tvPhotoInfo.setText(info);

            // 设置选择状态
            boolean isSelected = photoGroup.isSelectedForDeletion(photo);
            cbSelect.setChecked(isSelected);

            // 设置是否为建议保留的照片
            boolean isSuggestedKeep = photo.equals(photoGroup.getSuggestedKeepPhoto());
            if (isSuggestedKeep) {
                cbSelect.setEnabled(false);
                cbSelect.setChecked(false);
                btnKeepThis.setVisibility(View.INVISIBLE);
                ivPhoto.setAlpha(1.0f);
                // 添加一个标记表示这是建议保留的照片
                tvPhotoInfo.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_keep, 0);
            } else {
                cbSelect.setEnabled(true);
                btnKeepThis.setVisibility(View.VISIBLE);
                ivPhoto.setAlpha(isSelected ? 0.5f : 1.0f);
                tvPhotoInfo.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            }
        }
    }
}
