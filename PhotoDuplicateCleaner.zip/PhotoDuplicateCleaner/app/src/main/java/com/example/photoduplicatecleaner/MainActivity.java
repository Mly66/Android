package com.example.photoduplicatecleaner;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import com.example.photoduplicatecleaner.ui.ScanningActivity;
import com.example.photoduplicatecleaner.ui.SettingsActivity;
import com.example.photoduplicatecleaner.ui.ResultsActivity;
import com.example.photoduplicatecleaner.util.ScanResultsManager;

/**
 * 主Activity，应用的入口点
 * 显示开始扫描按钮、上次扫描结果（如果有）和隐私提示
 */
public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final String PREF_LAST_SCAN_GROUPS = "last_scan_groups";
    private static final String PREF_LAST_SCAN_SPACE = "last_scan_space";

    private Button btnStartScan;
    private TextView tvLastScanResult;
    private Button btnViewResults;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化视图
        btnStartScan = findViewById(R.id.btnStartScan);
        tvLastScanResult = findViewById(R.id.tvLastScanResult);
        btnViewResults = findViewById(R.id.btnViewResults);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        // 设置点击监听器
        btnStartScan.setOnClickListener(v -> checkPermissionAndStartScan());
        btnViewResults.setOnClickListener(v -> openLastResults());

        // 加载上次扫描结果（如果有）
        loadLastScanResults();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 每次回到主界面时重新加载上次扫描结果
        loadLastScanResults();
    }

    /**
     * 加载并显示上次扫描结果
     */
    private void loadLastScanResults() {
        int lastGroups = prefs.getInt(PREF_LAST_SCAN_GROUPS, 0);
        String lastSpace = prefs.getString(PREF_LAST_SCAN_SPACE, "0 MB");

        if (lastGroups > 0) {
            tvLastScanResult.setText(getString(R.string.last_scan_result, lastGroups, lastSpace));
            tvLastScanResult.setVisibility(View.VISIBLE);
            btnViewResults.setVisibility(View.VISIBLE);
        } else {
            tvLastScanResult.setVisibility(View.GONE);
            btnViewResults.setVisibility(View.GONE);
        }
    }

    /**
     * 检查存储权限并开始扫描
     */
    private void checkPermissionAndStartScan() {
        // 根据Android版本选择合适的权限
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ?
                Manifest.permission.READ_MEDIA_IMAGES :
                Manifest.permission.READ_EXTERNAL_STORAGE;

        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, PERMISSION_REQUEST_CODE);
        } else {
            startScanActivity();
        }
    }

    /**
     * 启动扫描Activity
     */
    private void startScanActivity() {
        Intent intent = new Intent(this, ScanningActivity.class);
        startActivity(intent);
    }

    /**
     * 打开上次扫描结果
     */
    private void openLastResults() {
        if (ScanResultsManager.getInstance().hasCachedResults()) {
            Intent intent = new Intent(this, ResultsActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, R.string.no_duplicates_found, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startScanActivity();
            } else {
                Toast.makeText(this, R.string.permission_denied_message, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
