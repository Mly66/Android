package com.example.photoduplicatecleaner.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.util.Log;

import java.io.IOException;

/**
 * 图像处理工具类，用于图像的预处理和变换
 */
public class ImageUtils {
    private static final String TAG = "ImageUtils";

    /**
     * 加载并预处理图像，用于特征提取
     * 
     * @param imagePath 图像文件路径
     * @param targetWidth 目标宽度
     * @param targetHeight 目标高度
     * @return 预处理后的Bitmap，如果处理失败则返回null
     */
    public static Bitmap loadAndPreprocessImage(String imagePath, int targetWidth, int targetHeight) {
        try {
            // 首先获取图像的尺寸，避免加载整个图像到内存
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(imagePath, options);
            
            // 计算缩放比例
            int width = options.outWidth;
            int height = options.outHeight;
            int inSampleSize = calculateInSampleSize(width, height, targetWidth, targetHeight);
            
            // 加载缩放后的图像
            options.inJustDecodeBounds = false;
            options.inSampleSize = inSampleSize;
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath, options);
            
            if (bitmap == null) {
                Log.e(TAG, "Failed to decode image: " + imagePath);
                return null;
            }
            
            // 处理EXIF方向信息
            bitmap = rotateImageIfRequired(bitmap, imagePath);
            
            // 调整到目标尺寸
            if (bitmap.getWidth() != targetWidth || bitmap.getHeight() != targetHeight) {
                bitmap = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true);
            }
            
            return bitmap;
        } catch (Exception e) {
            Log.e(TAG, "Error preprocessing image: " + imagePath, e);
            return null;
        }
    }
    
    /**
     * 计算合适的缩放比例
     */
    private static int calculateInSampleSize(int width, int height, int reqWidth, int reqHeight) {
        int inSampleSize = 1;
        
        if (height > reqHeight || width > reqWidth) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            
            // 计算最大的inSampleSize值，该值是2的幂，并且保持高度和宽度大于请求的高度和宽度
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }
        
        return inSampleSize;
    }
    
    /**
     * 根据EXIF信息旋转图像
     */
    private static Bitmap rotateImageIfRequired(Bitmap img, String path) {
        try {
            ExifInterface ei = new ExifInterface(path);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    return rotateImage(img, 90);
                case ExifInterface.ORIENTATION_ROTATE_180:
                    return rotateImage(img, 180);
                case ExifInterface.ORIENTATION_ROTATE_270:
                    return rotateImage(img, 270);
                default:
                    return img;
            }
        } catch (IOException e) {
            Log.e(TAG, "Error getting EXIF orientation: " + path, e);
            return img;
        }
    }
    
    /**
     * 旋转图像
     */
    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }
    
    /**
     * 将Bitmap转换为归一化的浮点数组，用于模型输入
     * 
     * @param bitmap 输入Bitmap
     * @return 归一化的浮点数组
     */
    public static float[] bitmapToFloatArray(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] intValues = new int[width * height];
        float[] floatValues = new float[width * height * 3]; // RGB三通道
        
        bitmap.getPixels(intValues, 0, width, 0, 0, width, height);
        
        for (int i = 0; i < intValues.length; i++) {
            final int val = intValues[i];
            // 提取RGB值并归一化到[-1,1]范围
            floatValues[i * 3] = ((val >> 16) & 0xFF) / 127.5f - 1.0f;     // R
            floatValues[i * 3 + 1] = ((val >> 8) & 0xFF) / 127.5f - 1.0f;  // G
            floatValues[i * 3 + 2] = (val & 0xFF) / 127.5f - 1.0f;         // B
        }
        
        return floatValues;
    }
}
