package com.example.photoduplicatecleaner.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 表示一组相似或重复的照片
 */
public class PhotoGroup {
    private String id;                  // 组唯一标识符
    private List<Photo> photos;         // 组内照片列表
    private boolean isDuplicate;        // 是否为完全重复（true）或相似（false）
    private Photo suggestedKeepPhoto;   // 建议保留的照片
    private List<Photo> selectedForDeletion; // 选中要删除的照片

    public PhotoGroup(String id, boolean isDuplicate) {
        this.id = id;
        this.isDuplicate = isDuplicate;
        this.photos = new ArrayList<>();
        this.selectedForDeletion = new ArrayList<>();
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public List<Photo> getPhotos() {
        return photos;
    }

    public void addPhoto(Photo photo) {
        if (!photos.contains(photo)) {
            photos.add(photo);
        }
    }

    public boolean isDuplicate() {
        return isDuplicate;
    }

    public void setDuplicate(boolean duplicate) {
        isDuplicate = duplicate;
    }

    public Photo getSuggestedKeepPhoto() {
        return suggestedKeepPhoto;
    }

    public void setSuggestedKeepPhoto(Photo suggestedKeepPhoto) {
        this.suggestedKeepPhoto = suggestedKeepPhoto;
    }

    public List<Photo> getSelectedForDeletion() {
        return selectedForDeletion;
    }

    public void selectForDeletion(Photo photo) {
        if (photos.contains(photo) && !photo.equals(suggestedKeepPhoto) && !selectedForDeletion.contains(photo)) {
            selectedForDeletion.add(photo);
        }
    }

    public void unselectForDeletion(Photo photo) {
        selectedForDeletion.remove(photo);
    }

    public void toggleSelection(Photo photo) {
        if (selectedForDeletion.contains(photo)) {
            unselectForDeletion(photo);
        } else {
            selectForDeletion(photo);
        }
    }

    public boolean isSelectedForDeletion(Photo photo) {
        return selectedForDeletion.contains(photo);
    }

    /**
     * 选择除指定照片外的所有照片进行删除
     * @param keepPhoto 要保留的照片
     */
    public void selectAllExcept(Photo keepPhoto) {
        selectedForDeletion.clear();
        for (Photo photo : photos) {
            if (!photo.equals(keepPhoto)) {
                selectedForDeletion.add(photo);
            }
        }
        // 更新建议保留的照片
        suggestedKeepPhoto = keepPhoto;
    }

    /**
     * 选择所有建议删除的照片（除了建议保留的照片）
     */
    public void selectAllSuggested() {
        selectedForDeletion.clear();
        for (Photo photo : photos) {
            if (!photo.equals(suggestedKeepPhoto)) {
                selectedForDeletion.add(photo);
            }
        }
    }

    /**
     * 反选所有照片
     */
    public void invertSelection() {
        List<Photo> newSelection = new ArrayList<>();
        for (Photo photo : photos) {
            if (!selectedForDeletion.contains(photo) && !photo.equals(suggestedKeepPhoto)) {
                newSelection.add(photo);
            }
        }
        selectedForDeletion.clear();
        selectedForDeletion.addAll(newSelection);
    }

    /**
     * 获取组内照片数量
     * @return 照片数量
     */
    public int getPhotoCount() {
        return photos.size();
    }

    /**
     * 获取选中删除的照片数量
     * @return 选中删除的照片数量
     */
    public int getSelectedCount() {
        return selectedForDeletion.size();
    }

    /**
     * 获取组内所有照片的总大小
     * @return 总大小（字节）
     */
    public long getTotalSize() {
        long total = 0;
        for (Photo photo : photos) {
            total += photo.getSize();
        }
        return total;
    }

    /**
     * 获取选中删除照片的总大小
     * @return 选中删除照片的总大小（字节）
     */
    public long getSelectedSize() {
        long total = 0;
        for (Photo photo : selectedForDeletion) {
            total += photo.getSize();
        }
        return total;
    }

    /**
     * 获取格式化的可释放空间大小
     * @return 格式化的可释放空间大小字符串（如 "1.5 MB"）
     */
    public String getFormattedSelectedSize() {
        long size = getSelectedSize();
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / (1024.0 * 1024));
        } else {
            return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
        }
    }
}
