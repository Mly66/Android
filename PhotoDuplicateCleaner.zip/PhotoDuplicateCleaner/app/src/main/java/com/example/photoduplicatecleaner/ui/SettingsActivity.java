package com.example.photoduplicatecleaner.ui;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.adapter.SettingsAdapter;
import com.example.photoduplicatecleaner.model.SettingItem;

import java.util.ArrayList;
import java.util.List;

/**
 * 设置界面，允许用户配置应用参数
 */
public class SettingsActivity extends AppCompatActivity implements SettingsAdapter.OnSettingChangeListener {

    private RecyclerView recyclerView;
    private SettingsAdapter adapter;
    private List<SettingItem> settingItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // 设置标题和返回按钮
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.settings);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 初始化视图
        recyclerView = findViewById(R.id.recyclerViewSettings);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        // 初始化设置项
        initSettingItems();

        // 设置适配器
        adapter = new SettingsAdapter(settingItems, this);
        recyclerView.setAdapter(adapter);
    }

    /**
     * 初始化设置项
     */
    private void initSettingItems() {
        settingItems = new ArrayList<>();

        // 相似度阈值设置
        settingItems.add(new SettingItem(
                SettingItem.TYPE_HEADER,
                getString(R.string.similarity_settings),
                null,
                false,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SLIDER,
                getString(R.string.duplicate_threshold),
                getString(R.string.duplicate_threshold_desc),
                false,
                98, // 默认值98%
                value -> String.format("%d%%", value)
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SLIDER,
                getString(R.string.similar_threshold),
                getString(R.string.similar_threshold_desc),
                false,
                85, // 默认值85%
                value -> String.format("%d%%", value)
        ));

        // 扫描设置
        settingItems.add(new SettingItem(
                SettingItem.TYPE_HEADER,
                getString(R.string.scan_settings),
                null,
                false,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SWITCH,
                getString(R.string.scan_screenshots),
                getString(R.string.scan_screenshots_desc),
                true,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SWITCH,
                getString(R.string.scan_downloads),
                getString(R.string.scan_downloads_desc),
                true,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SWITCH,
                getString(R.string.scan_camera),
                getString(R.string.scan_camera_desc),
                true,
                0,
                null
        ));

        // 性能设置
        settingItems.add(new SettingItem(
                SettingItem.TYPE_HEADER,
                getString(R.string.performance_settings),
                null,
                false,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SLIDER,
                getString(R.string.thread_count),
                getString(R.string.thread_count_desc),
                false,
                4, // 默认值4线程
                value -> String.valueOf(value)
        ));

        // 隐私设置
        settingItems.add(new SettingItem(
                SettingItem.TYPE_HEADER,
                getString(R.string.privacy_settings),
                null,
                false,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_SWITCH,
                getString(R.string.local_processing_only),
                getString(R.string.local_processing_only_desc),
                true, // 默认开启本地处理
                0,
                null
        ));

        // 关于
        settingItems.add(new SettingItem(
                SettingItem.TYPE_HEADER,
                getString(R.string.about),
                null,
                false,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_INFO,
                getString(R.string.app_version),
                "1.0.0",
                false,
                0,
                null
        ));

        settingItems.add(new SettingItem(
                SettingItem.TYPE_BUTTON,
                getString(R.string.privacy_policy),
                null,
                false,
                0,
                null
        ));
    }

    @Override
    public void onSwitchChanged(int position, boolean isChecked) {
        SettingItem item = settingItems.get(position);
        
        // 处理特殊情况
        if (item.getTitle().equals(getString(R.string.local_processing_only)) && !isChecked) {
            // 不允许关闭本地处理
            Toast.makeText(this, R.string.local_processing_required, Toast.LENGTH_SHORT).show();
            item.setChecked(true);
            adapter.notifyItemChanged(position);
            return;
        }
        
        // 保存设置
        item.setChecked(isChecked);
        saveSettings();
    }

    @Override
    public void onSliderChanged(int position, int value) {
        SettingItem item = settingItems.get(position);
        item.setValue(value);
        saveSettings();
    }

    @Override
    public void onButtonClicked(int position) {
        SettingItem item = settingItems.get(position);
        
        if (item.getTitle().equals(getString(R.string.privacy_policy))) {
            // 显示隐私政策
            showPrivacyPolicy();
        }
    }

    /**
     * 保存设置
     */
    private void saveSettings() {
        // 实际应用中，这里会将设置保存到SharedPreferences
        // 为了简化，这里只显示一个Toast
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示隐私政策
     */
    private void showPrivacyPolicy() {
        // 实际应用中，这里会打开一个包含隐私政策的Activity或对话框
        Toast.makeText(this, R.string.privacy_policy_summary, Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
