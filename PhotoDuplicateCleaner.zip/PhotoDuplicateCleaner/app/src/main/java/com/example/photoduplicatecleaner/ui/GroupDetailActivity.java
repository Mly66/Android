package com.example.photoduplicatecleaner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.adapter.PhotoAdapter;
import com.example.photoduplicatecleaner.model.Photo;
import com.example.photoduplicatecleaner.model.PhotoGroup;
import com.example.photoduplicatecleaner.viewmodel.MainViewModel;

import java.util.List;

/**
 * 分组详情屏幕，显示组内所有照片并允许用户选择要删除的照片
 */
public class GroupDetailActivity extends AppCompatActivity implements PhotoAdapter.OnPhotoClickListener {

    private MainViewModel viewModel;
    private RecyclerView recyclerView;
    private PhotoAdapter adapter;
    private TextView tvGroupTitle;
    private Button btnSelectAll;
    private Button btnInvertSelection;
    
    private PhotoGroup currentGroup;
    private String groupId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_detail);
        
        // 启用返回按钮
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 获取组ID
        groupId = getIntent().getStringExtra("GROUP_ID");
        if (groupId == null) {
            finish();
            return;
        }

        // 初始化视图
        recyclerView = findViewById(R.id.recyclerViewPhotos);
        tvGroupTitle = findViewById(R.id.tvGroupTitle);
        btnSelectAll = findViewById(R.id.btnSelectAll);
        btnInvertSelection = findViewById(R.id.btnInvertSelection);

        // 设置RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3)); // 3列网格
        adapter = new PhotoAdapter(this);
        recyclerView.setAdapter(adapter);

        // 获取ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // 设置按钮点击监听器
        btnSelectAll.setOnClickListener(v -> selectAllInGroup());
        btnInvertSelection.setOnClickListener(v -> invertSelection());

        // 加载组内照片
        loadGroupPhotos();
    }

    /**
     * 加载组内照片
     */
    private void loadGroupPhotos() {
        List<PhotoGroup> groups = viewModel.getCachedResults();
        for (PhotoGroup group : groups) {
            if (group.getId().equals(groupId)) {
                currentGroup = group;
                break;
            }
        }

        if (currentGroup == null) {
            finish();
            return;
        }

        // 设置标题
        String groupType = currentGroup.isDuplicate() ? "重复照片组" : "相似照片组";
        tvGroupTitle.setText(String.format("%s (%d张)", groupType, currentGroup.getPhotoCount()));

        // 设置照片列表
        adapter.setPhotoGroup(currentGroup);
    }

    /**
     * 选择组内所有照片（除了建议保留的）
     */
    private void selectAllInGroup() {
        if (currentGroup != null) {
            viewModel.selectAllSuggested(currentGroup);
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * 反选组内照片
     */
    private void invertSelection() {
        if (currentGroup != null) {
            viewModel.invertSelection(currentGroup);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onPhotoClick(Photo photo) {
        // 跳转到大图预览页面
        Intent intent = new Intent(this, ImageViewActivity.class);
        intent.putExtra("GROUP_ID", groupId);
        intent.putExtra("PHOTO_ID", photo.getId());
        startActivity(intent);
    }

    @Override
    public void onPhotoLongClick(Photo photo) {
        // 切换照片选择状态
        if (currentGroup != null) {
            viewModel.togglePhotoSelection(currentGroup, photo);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onKeepThisClick(Photo photo) {
        // 保留这张，删除其他
        if (currentGroup != null) {
            viewModel.selectAllExcept(currentGroup, photo);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
