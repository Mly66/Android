package com.example.photoduplicatecleaner.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.preference.PreferenceManager;

import com.example.photoduplicatecleaner.model.PhotoGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * 扫描结果管理器，负责缓存和恢复扫描结果
 */
public class ScanResultsManager {
    private static final String TAG = "ScanResultsManager";
    private static ScanResultsManager instance;
    
    private List<PhotoGroup> cachedResults;
    
    private ScanResultsManager() {
        cachedResults = new ArrayList<>();
    }
    
    /**
     * 获取单例实例
     */
    public static synchronized ScanResultsManager getInstance() {
        if (instance == null) {
            instance = new ScanResultsManager();
        }
        return instance;
    }
    
    /**
     * 缓存扫描结果
     * 
     * @param results 扫描结果
     */
    public void cacheResults(List<PhotoGroup> results) {
        cachedResults.clear();
        if (results != null) {
            cachedResults.addAll(results);
        }
    }
    
    /**
     * 获取缓存的扫描结果
     * 
     * @return 缓存的扫描结果
     */
    public List<PhotoGroup> getCachedResults() {
        return new ArrayList<>(cachedResults);
    }
    
    /**
     * 检查是否有缓存的扫描结果
     * 
     * @return 是否有缓存的扫描结果
     */
    public boolean hasCachedResults() {
        return !cachedResults.isEmpty();
    }
    
    /**
     * 清除缓存的扫描结果
     */
    public void clearCachedResults() {
        cachedResults.clear();
    }
    
    /**
     * 保存上次扫描的统计信息到SharedPreferences
     * 
     * @param context 应用上下文
     * @param groupCount 分组数量
     * @param totalSize 可释放的总空间大小
     */
    public void saveLastScanStats(Context context, int groupCount, String totalSize) {
        try {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("last_scan_groups", groupCount);
            editor.putString("last_scan_space", totalSize);
            editor.apply();
            
            Log.d(TAG, "Saved last scan stats: " + groupCount + " groups, " + totalSize);
        } catch (Exception e) {
            Log.e(TAG, "Error saving last scan stats", e);
        }
    }
    
    /**
     * 计算所有分组中选中删除照片的总大小
     * 
     * @return 格式化的总大小字符串
     */
    public String calculateTotalSelectedSize() {
        long totalSize = 0;
        for (PhotoGroup group : cachedResults) {
            totalSize += group.getSelectedSize();
        }
        
        return formatSize(totalSize);
    }
    
    /**
     * 格式化文件大小
     * 
     * @param size 文件大小（字节）
     * @return 格式化的文件大小字符串
     */
    private String formatSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / (1024.0 * 1024));
        } else {
            return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
        }
    }
}
