package com.example.photoduplicatecleaner.repository;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.photoduplicatecleaner.model.Photo;
import com.example.photoduplicatecleaner.model.PhotoGroup;
import com.example.photoduplicatecleaner.ml.TFLiteModelManager;
import com.example.photoduplicatecleaner.util.ImageUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 照片仓库类，负责照片的扫描、特征提取和相似度分析
 */
public class PhotoRepository {
    private static final String TAG = "PhotoRepository";
    private static final float DUPLICATE_THRESHOLD = 0.98f; // 重复照片的相似度阈值
    private static final float SIMILAR_THRESHOLD = 0.85f;   // 相似照片的相似度阈值
    
    private static PhotoRepository instance;
    private final Context context;
    private final ExecutorService executor;
    private final TFLiteModelManager modelManager;
    
    private final MutableLiveData<List<Photo>> allPhotos = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<PhotoGroup>> photoGroups = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<Integer> scanProgress = new MutableLiveData<>(0);
    private final MutableLiveData<Boolean> isScanning = new MutableLiveData<>(false);
    
    private PhotoRepository(Context context) {
        this.context = context.getApplicationContext();
        this.executor = Executors.newFixedThreadPool(4); // 使用4个线程的线程池
        this.modelManager = TFLiteModelManager.getInstance();
    }
    
    /**
     * 获取单例实例
     */
    public static synchronized PhotoRepository getInstance(Context context) {
        if (instance == null) {
            instance = new PhotoRepository(context);
        }
        return instance;
    }
    
    /**
     * 开始扫描设备上的照片
     */
    public void startScan() {
        if (isScanning.getValue() != null && isScanning.getValue()) {
            Log.w(TAG, "Scan already in progress");
            return;
        }
        
        isScanning.postValue(true);
        scanProgress.postValue(0);
        
        executor.execute(() -> {
            try {
                // 确保模型已加载
                if (!modelManager.loadModel(context)) {
                    Log.e(TAG, "Failed to load TFLite model");
                    isScanning.postValue(false);
                    return;
                }
                
                // 扫描照片
                List<Photo> photos = scanDevicePhotos();
                allPhotos.postValue(photos);
                
                // 提取特征并分析相似度
                List<PhotoGroup> groups = findDuplicateAndSimilarPhotos(photos);
                photoGroups.postValue(groups);
                
                // 扫描完成
                isScanning.postValue(false);
                scanProgress.postValue(100);
                
                Log.d(TAG, "Scan completed. Found " + photos.size() + " photos and " + groups.size() + " groups");
            } catch (Exception e) {
                Log.e(TAG, "Error during scan", e);
                isScanning.postValue(false);
            }
        });
    }
    
    /**
     * 取消正在进行的扫描
     */
    public void cancelScan() {
        if (isScanning.getValue() != null && isScanning.getValue()) {
            // 不能直接中断线程池，但可以设置标志位
            isScanning.postValue(false);
            Log.d(TAG, "Scan cancelled");
        }
    }
    
    /**
     * 扫描设备上的照片
     * 
     * @return 照片列表
     */
    private List<Photo> scanDevicePhotos() {
        List<Photo> photos = new ArrayList<>();
        ContentResolver resolver = context.getContentResolver();
        
        // 定义查询参数
        Uri collection;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        }
        
        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DATE_MODIFIED,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT
        };
        
        String selection = MediaStore.Images.Media.SIZE + " > 0"; // 排除大小为0的文件
        String sortOrder = MediaStore.Images.Media.DATE_MODIFIED + " DESC";
        
        try (Cursor cursor = resolver.query(collection, projection, selection, null, sortOrder)) {
            if (cursor == null) {
                Log.e(TAG, "Failed to query MediaStore");
                return photos;
            }
            
            int idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            int nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            int sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
            int dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
            int dateModifiedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
            int widthColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH);
            int heightColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT);
            
            int totalCount = cursor.getCount();
            int currentCount = 0;
            
            while (cursor.moveToNext() && (isScanning.getValue() == null || isScanning.getValue())) {
                String id = cursor.getString(idColumn);
                String path = cursor.getString(pathColumn);
                String name = cursor.getString(nameColumn);
                long size = cursor.getLong(sizeColumn);
                long dateAdded = cursor.getLong(dateAddedColumn);
                long dateModified = cursor.getLong(dateModifiedColumn);
                int width = cursor.getInt(widthColumn);
                int height = cursor.getInt(heightColumn);
                
                // 创建Photo对象
                Photo photo = new Photo(id, path, size, name, dateAdded, dateModified, width, height);
                photos.add(photo);
                
                // 更新进度
                currentCount++;
                int progress = (int) ((currentCount / (float) totalCount) * 50); // 扫描占总进度的50%
                scanProgress.postValue(progress);
            }
            
            Log.d(TAG, "Scanned " + photos.size() + " photos");
        } catch (Exception e) {
            Log.e(TAG, "Error scanning photos", e);
        }
        
        return photos;
    }
    
    /**
     * 查找重复和相似的照片
     * 
     * @param photos 照片列表
     * @return 照片分组列表
     */
    private List<PhotoGroup> findDuplicateAndSimilarPhotos(List<Photo> photos) {
        List<PhotoGroup> groups = new ArrayList<>();
        
        if (photos.isEmpty()) {
            return groups;
        }
        
        // 提取特征
        int totalCount = photos.size();
        int currentCount = 0;
        
        for (Photo photo : photos) {
            if (isScanning.getValue() == null || !isScanning.getValue()) {
                break; // 如果扫描被取消，则退出循环
            }
            
            try {
                // 加载并预处理图像
                android.graphics.Bitmap bitmap = ImageUtils.loadAndPreprocessImage(photo.getPath(), 224, 224);
                if (bitmap != null) {
                    // 提取特征
                    float[] features = modelManager.extractFeatures(bitmap);
                    photo.setFeatures(features);
                    bitmap.recycle();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error extracting features for photo: " + photo.getPath(), e);
            }
            
            // 更新进度
            currentCount++;
            int progress = 50 + (int) ((currentCount / (float) totalCount) * 25); // 特征提取占总进度的25%
            scanProgress.postValue(progress);
        }
        
        // 计算相似度并分组
        boolean[] processed = new boolean[photos.size()];
        currentCount = 0;
        
        for (int i = 0; i < photos.size(); i++) {
            if (isScanning.getValue() == null || !isScanning.getValue()) {
                break; // 如果扫描被取消，则退出循环
            }
            
            if (processed[i]) {
                continue; // 跳过已处理的照片
            }
            
            Photo photo1 = photos.get(i);
            if (photo1.getFeatures() == null) {
                continue; // 跳过没有特征的照片
            }
            
            PhotoGroup group = null;
            
            for (int j = i + 1; j < photos.size(); j++) {
                if (processed[j]) {
                    continue; // 跳过已处理的照片
                }
                
                Photo photo2 = photos.get(j);
                if (photo2.getFeatures() == null) {
                    continue; // 跳过没有特征的照片
                }
                
                // 计算相似度
                float similarity = TFLiteModelManager.cosineSimilarity(photo1.getFeatures(), photo2.getFeatures());
                
                // 如果相似度超过阈值，则添加到同一组
                if (similarity >= SIMILAR_THRESHOLD) {
                    if (group == null) {
                        // 创建新组
                        group = new PhotoGroup(UUID.randomUUID().toString(), similarity >= DUPLICATE_THRESHOLD);
                        group.addPhoto(photo1);
                        processed[i] = true;
                    }
                    
                    group.addPhoto(photo2);
                    processed[j] = true;
                    
                    // 如果是完全重复，则更新组的类型
                    if (similarity >= DUPLICATE_THRESHOLD) {
                        group.setDuplicate(true);
                    }
                }
            }
            
            // 如果找到了组，则添加到结果中
            if (group != null && group.getPhotoCount() > 1) {
                // 设置建议保留的照片（默认选择最新的）
                Photo suggestedKeep = findNewestPhoto(group.getPhotos());
                group.setSuggestedKeepPhoto(suggestedKeep);
                
                // 默认选择除建议保留外的所有照片进行删除
                group.selectAllSuggested();
                
                groups.add(group);
            }
            
            // 更新进度
            currentCount++;
            int progress = 75 + (int) ((currentCount / (float) totalCount) * 25); // 分组占总进度的25%
            scanProgress.postValue(progress);
        }
        
        return groups;
    }
    
    /**
     * 查找最新的照片
     * 
     * @param photos 照片列表
     * @return 最新的照片
     */
    private Photo findNewestPhoto(List<Photo> photos) {
        Photo newest = null;
        long newestTime = 0;
        
        for (Photo photo : photos) {
            if (newest == null || photo.getDateModified() > newestTime) {
                newest = photo;
                newestTime = photo.getDateModified();
            }
        }
        
        return newest;
    }
    
    /**
     * 获取所有照片的LiveData
     */
    public LiveData<List<Photo>> getAllPhotos() {
        return allPhotos;
    }
    
    /**
     * 获取照片分组的LiveData
     */
    public LiveData<List<PhotoGroup>> getPhotoGroups() {
        return photoGroups;
    }
    
    /**
     * 获取扫描进度的LiveData
     */
    public LiveData<Integer> getScanProgress() {
        return scanProgress;
    }
    
    /**
     * 获取是否正在扫描的LiveData
     */
    public LiveData<Boolean> getIsScanning() {
        return isScanning;
    }
    
    /**
     * 删除选中的照片
     * 
     * @param groups 要处理的照片组列表
     * @return 成功删除的照片数量
     */
    public int deleteSelectedPhotos(List<PhotoGroup> groups) {
        int deletedCount = 0;
        
        for (PhotoGroup group : groups) {
            List<Photo> toDelete = group.getSelectedForDeletion();
            for (Photo photo : toDelete) {
                if (deletePhoto(photo)) {
                    deletedCount++;
                }
            }
        }
        
        // 更新分组
        if (deletedCount > 0) {
            List<PhotoGroup> updatedGroups = new ArrayList<>();
            for (PhotoGroup group : groups) {
                // 移除已删除的照片
                List<Photo> remainingPhotos = new ArrayList<>(group.getPhotos());
                remainingPhotos.removeAll(group.getSelectedForDeletion());
                
                // 如果组内还有多张照片，则保留该组
                if (remainingPhotos.size() > 1) {
                    PhotoGroup updatedGroup = new PhotoGroup(group.getId(), group.isDuplicate());
                    for (Photo photo : remainingPhotos) {
                        updatedGroup.addPhoto(photo);
                    }
                    
                    // 更新建议保留的照片
                    Photo suggestedKeep = findNewestPhoto(updatedGroup.getPhotos());
                    updatedGroup.setSuggestedKeepPhoto(suggestedKeep);
                    
                    updatedGroups.add(updatedGroup);
                }
            }
            
            photoGroups.postValue(updatedGroups);
        }
        
        return deletedCount;
    }
    
    /**
     * 删除单张照片
     * 
     * @param photo 要删除的照片
     * @return 是否成功删除
     */
    private boolean deletePhoto(Photo photo) {
        try {
            ContentResolver resolver = context.getContentResolver();
            Uri photoUri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
            String selection = MediaStore.Images.Media._ID + "=?";
            String[] selectionArgs = {photo.getId()};
            
            int deletedRows = resolver.delete(photoUri, selection, selectionArgs);
            return deletedRows > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error deleting photo: " + photo.getPath(), e);
            return false;
        }
    }
    
    /**
     * 释放资源
     */
    public void release() {
        executor.shutdown();
        modelManager.close();
    }
}
