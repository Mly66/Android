package com.example.photoduplicatecleaner.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.model.SettingItem;

import java.util.List;

/**
 * 设置适配器，用于在设置界面中显示不同类型的设置项
 */
public class SettingsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<SettingItem> settingItems;
    private final OnSettingChangeListener listener;

    public interface OnSettingChangeListener {
        void onSwitchChanged(int position, boolean isChecked);
        void onSliderChanged(int position, int value);
        void onButtonClicked(int position);
    }

    public SettingsAdapter(List<SettingItem> settingItems, OnSettingChangeListener listener) {
        this.settingItems = settingItems;
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        return settingItems.get(position).getType();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        
        switch (viewType) {
            case SettingItem.TYPE_HEADER:
                View headerView = inflater.inflate(R.layout.item_setting_header, parent, false);
                return new HeaderViewHolder(headerView);
                
            case SettingItem.TYPE_SWITCH:
                View switchView = inflater.inflate(R.layout.item_setting_switch, parent, false);
                return new SwitchViewHolder(switchView);
                
            case SettingItem.TYPE_SLIDER:
                View sliderView = inflater.inflate(R.layout.item_setting_slider, parent, false);
                return new SliderViewHolder(sliderView);
                
            case SettingItem.TYPE_INFO:
                View infoView = inflater.inflate(R.layout.item_setting_info, parent, false);
                return new InfoViewHolder(infoView);
                
            case SettingItem.TYPE_BUTTON:
                View buttonView = inflater.inflate(R.layout.item_setting_button, parent, false);
                return new ButtonViewHolder(buttonView);
                
            default:
                throw new IllegalArgumentException("Unknown view type: " + viewType);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        SettingItem item = settingItems.get(position);
        
        switch (holder.getItemViewType()) {
            case SettingItem.TYPE_HEADER:
                ((HeaderViewHolder) holder).bind(item);
                break;
                
            case SettingItem.TYPE_SWITCH:
                ((SwitchViewHolder) holder).bind(item, position);
                break;
                
            case SettingItem.TYPE_SLIDER:
                ((SliderViewHolder) holder).bind(item, position);
                break;
                
            case SettingItem.TYPE_INFO:
                ((InfoViewHolder) holder).bind(item);
                break;
                
            case SettingItem.TYPE_BUTTON:
                ((ButtonViewHolder) holder).bind(item, position);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return settingItems.size();
    }

    // 标题ViewHolder
    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvHeader;

        HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvHeader = itemView.findViewById(R.id.tvHeader);
        }

        void bind(SettingItem item) {
            tvHeader.setText(item.getTitle());
        }
    }

    // 开关ViewHolder
    class SwitchViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvTitle;
        private final TextView tvDescription;
        private final Switch switchSetting;

        SwitchViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            switchSetting = itemView.findViewById(R.id.switchSetting);
        }

        void bind(SettingItem item, int position) {
            tvTitle.setText(item.getTitle());
            
            if (item.getDescription() != null) {
                tvDescription.setText(item.getDescription());
                tvDescription.setVisibility(View.VISIBLE);
            } else {
                tvDescription.setVisibility(View.GONE);
            }
            
            // 设置开关状态，但不触发监听器
            switchSetting.setOnCheckedChangeListener(null);
            switchSetting.setChecked(item.isChecked());
            
            // 设置开关监听器
            switchSetting.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (listener != null) {
                    listener.onSwitchChanged(position, isChecked);
                }
            });
        }
    }

    // 滑块ViewHolder
    class SliderViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvTitle;
        private final TextView tvDescription;
        private final SeekBar seekBar;
        private final TextView tvValue;

        SliderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            seekBar = itemView.findViewById(R.id.seekBar);
            tvValue = itemView.findViewById(R.id.tvValue);
        }

        void bind(SettingItem item, int position) {
            tvTitle.setText(item.getTitle());
            
            if (item.getDescription() != null) {
                tvDescription.setText(item.getDescription());
                tvDescription.setVisibility(View.VISIBLE);
            } else {
                tvDescription.setVisibility(View.GONE);
            }
            
            // 设置滑块值，但不触发监听器
            seekBar.setOnSeekBarChangeListener(null);
            seekBar.setProgress(item.getValue());
            tvValue.setText(item.getFormattedValue());
            
            // 设置滑块监听器
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        tvValue.setText(item.getFormattedValue());
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    if (listener != null) {
                        listener.onSliderChanged(position, seekBar.getProgress());
                    }
                }
            });
        }
    }

    // 信息ViewHolder
    static class InfoViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvTitle;
        private final TextView tvValue;

        InfoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvValue = itemView.findViewById(R.id.tvValue);
        }

        void bind(SettingItem item) {
            tvTitle.setText(item.getTitle());
            tvValue.setText(item.getDescription());
        }
    }

    // 按钮ViewHolder
    class ButtonViewHolder extends RecyclerView.ViewHolder {
        private final Button btnSetting;

        ButtonViewHolder(@NonNull View itemView) {
            super(itemView);
            btnSetting = itemView.findViewById(R.id.btnSetting);
        }

        void bind(SettingItem item, int position) {
            btnSetting.setText(item.getTitle());
            
            btnSetting.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onButtonClicked(position);
                }
            });
        }
    }
}
