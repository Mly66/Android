package com.example.photoduplicatecleaner.model;

/**
 * 设置项实体类，用于在设置界面中显示不同类型的设置项
 */
public class SettingItem {
    // 设置项类型
    public static final int TYPE_HEADER = 0;    // 标题
    public static final int TYPE_SWITCH = 1;    // 开关
    public static final int TYPE_SLIDER = 2;    // 滑块
    public static final int TYPE_INFO = 3;      // 信息
    public static final int TYPE_BUTTON = 4;    // 按钮

    private int type;           // 设置项类型
    private String title;       // 标题
    private String description; // 描述
    private boolean checked;    // 开关状态
    private int value;          // 滑块值
    private ValueFormatter valueFormatter; // 值格式化器

    /**
     * 值格式化器接口，用于将滑块值转换为显示文本
     */
    public interface ValueFormatter {
        String format(int value);
    }

    public SettingItem(int type, String title, String description, boolean checked, int value, ValueFormatter valueFormatter) {
        this.type = type;
        this.title = title;
        this.description = description;
        this.checked = checked;
        this.value = value;
        this.valueFormatter = valueFormatter;
    }

    // Getters and Setters
    public int getType() {
        return type;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getFormattedValue() {
        return valueFormatter != null ? valueFormatter.format(value) : String.valueOf(value);
    }
}
