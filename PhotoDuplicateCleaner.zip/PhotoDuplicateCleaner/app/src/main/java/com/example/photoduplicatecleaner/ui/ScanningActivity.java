package com.example.photoduplicatecleaner.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.viewmodel.MainViewModel;

/**
 * 扫描中界面，显示扫描进度和允许用户取消扫描
 */
public class ScanningActivity extends AppCompatActivity {

    private MainViewModel viewModel;
    private ProgressBar progressBar;
    private TextView tvProgressText;
    private Button btnCancelScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanning);

        // 初始化视图
        progressBar = findViewById(R.id.progressBar);
        tvProgressText = findViewById(R.id.tvProgressText);
        btnCancelScan = findViewById(R.id.btnCancelScan);

        // 获取ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // 设置取消按钮点击监听器
        btnCancelScan.setOnClickListener(v -> {
            viewModel.cancelScan();
            finish();
        });

        // 观察扫描进度
        viewModel.getScanProgress().observe(this, progress -> {
            progressBar.setProgress(progress);
            updateProgressText(progress);
        });

        // 观察扫描状态
        viewModel.getIsScanning().observe(this, isScanning -> {
            if (!isScanning) {
                // 扫描完成或被取消，跳转到结果页面
                navigateToResults();
            }
        });

        // 开始扫描
        viewModel.startScan();
    }

    /**
     * 更新进度文本
     */
    private void updateProgressText(int progress) {
        if (progress < 50) {
            // 扫描阶段
            tvProgressText.setText(getString(R.string.scan_progress, progress * 2, 100));
        } else if (progress < 75) {
            // 特征提取阶段
            tvProgressText.setText(getString(R.string.analyzing_image, (progress - 50) * 4));
        } else {
            // 相似度分析阶段
            tvProgressText.setText(getString(R.string.analyzing_image, (progress - 75) * 4));
        }
    }

    /**
     * 导航到结果页面
     */
    private void navigateToResults() {
        Intent intent = new Intent(this, ResultsActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        // 询问用户是否确定要取消扫描
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(R.string.cancel_scan);
        builder.setMessage("确定要取消扫描吗？");
        builder.setPositiveButton(R.string.confirm, (dialog, which) -> {
            viewModel.cancelScan();
            finish();
        });
        builder.setNegativeButton(R.string.cancel, null);
        builder.show();
    }
}
