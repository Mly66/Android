package com.example.photoduplicatecleaner.viewmodel;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.photoduplicatecleaner.model.Photo;
import com.example.photoduplicatecleaner.model.PhotoGroup;
import com.example.photoduplicatecleaner.repository.PhotoRepository;
import com.example.photoduplicatecleaner.util.ScanResultsManager;

import java.util.List;

/**
 * 主ViewModel，负责处理UI与数据层之间的交互
 */
public class MainViewModel extends AndroidViewModel {
    private final PhotoRepository repository;
    private final ScanResultsManager resultsManager;
    
    private final LiveData<List<Photo>> allPhotos;
    private final LiveData<List<PhotoGroup>> photoGroups;
    private final LiveData<Integer> scanProgress;
    private final LiveData<Boolean> isScanning;
    
    private final MutableLiveData<String> totalSelectedSize = new MutableLiveData<>("0 B");
    private final MutableLiveData<Integer> totalSelectedCount = new MutableLiveData<>(0);
    
    public MainViewModel(@NonNull Application application) {
        super(application);
        repository = PhotoRepository.getInstance(application);
        resultsManager = ScanResultsManager.getInstance();
        
        allPhotos = repository.getAllPhotos();
        photoGroups = repository.getPhotoGroups();
        scanProgress = repository.getScanProgress();
        isScanning = repository.getIsScanning();
        
        // 监听photoGroups的变化，更新缓存和统计信息
        MediatorLiveData<List<PhotoGroup>> mediatorPhotoGroups = new MediatorLiveData<>();
        mediatorPhotoGroups.addSource(photoGroups, groups -> {
            if (groups != null) {
                resultsManager.cacheResults(groups);
                updateStatistics(groups);
                mediatorPhotoGroups.setValue(groups);
                
                // 保存扫描统计信息
                Context context = getApplication().getApplicationContext();
                resultsManager.saveLastScanStats(context, groups.size(), calculateTotalSpaceToFree(groups));
            }
        });
    }
    
    /**
     * 开始扫描照片
     */
    public void startScan() {
        repository.startScan();
    }
    
    /**
     * 取消扫描
     */
    public void cancelScan() {
        repository.cancelScan();
    }
    
    /**
     * 删除选中的照片
     * 
     * @return 成功删除的照片数量
     */
    public int deleteSelectedPhotos() {
        List<PhotoGroup> groups = photoGroups.getValue();
        if (groups == null || groups.isEmpty()) {
            return 0;
        }
        
        return repository.deleteSelectedPhotos(groups);
    }
    
    /**
     * 更新照片选择状态
     * 
     * @param group 照片组
     * @param photo 照片
     * @param selected 是否选中
     */
    public void updatePhotoSelection(PhotoGroup group, Photo photo, boolean selected) {
        if (selected) {
            group.selectForDeletion(photo);
        } else {
            group.unselectForDeletion(photo);
        }
        
        updateStatistics(photoGroups.getValue());
    }
    
    /**
     * 切换照片选择状态
     * 
     * @param group 照片组
     * @param photo 照片
     */
    public void togglePhotoSelection(PhotoGroup group, Photo photo) {
        group.toggleSelection(photo);
        updateStatistics(photoGroups.getValue());
    }
    
    /**
     * 选择除指定照片外的所有照片进行删除
     * 
     * @param group 照片组
     * @param keepPhoto 要保留的照片
     */
    public void selectAllExcept(PhotoGroup group, Photo keepPhoto) {
        group.selectAllExcept(keepPhoto);
        updateStatistics(photoGroups.getValue());
    }
    
    /**
     * 选择所有建议删除的照片
     * 
     * @param group 照片组
     */
    public void selectAllSuggested(PhotoGroup group) {
        group.selectAllSuggested();
        updateStatistics(photoGroups.getValue());
    }
    
    /**
     * 反选照片组中的照片
     * 
     * @param group 照片组
     */
    public void invertSelection(PhotoGroup group) {
        group.invertSelection();
        updateStatistics(photoGroups.getValue());
    }
    
    /**
     * 选择所有组中建议删除的照片
     */
    public void selectAllSuggestedInAllGroups() {
        List<PhotoGroup> groups = photoGroups.getValue();
        if (groups == null) {
            return;
        }
        
        for (PhotoGroup group : groups) {
            group.selectAllSuggested();
        }
        
        updateStatistics(groups);
    }
    
    /**
     * 更新统计信息
     * 
     * @param groups 照片组列表
     */
    private void updateStatistics(List<PhotoGroup> groups) {
        if (groups == null) {
            totalSelectedSize.setValue("0 B");
            totalSelectedCount.setValue(0);
            return;
        }
        
        int count = 0;
        long size = 0;
        
        for (PhotoGroup group : groups) {
            count += group.getSelectedCount();
            size += group.getSelectedSize();
        }
        
        totalSelectedCount.setValue(count);
        totalSelectedSize.setValue(formatSize(size));
    }
    
    /**
     * 计算所有组中可释放的总空间
     * 
     * @param groups 照片组列表
     * @return 格式化的总空间大小字符串
     */
    private String calculateTotalSpaceToFree(List<PhotoGroup> groups) {
        if (groups == null) {
            return "0 B";
        }
        
        long totalSize = 0;
        for (PhotoGroup group : groups) {
            totalSize += group.getSelectedSize();
        }
        
        return formatSize(totalSize);
    }
    
    /**
     * 格式化文件大小
     * 
     * @param size 文件大小（字节）
     * @return 格式化的文件大小字符串
     */
    private String formatSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / (1024.0 * 1024));
        } else {
            return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
        }
    }
    
    /**
     * 获取所有照片的LiveData
     */
    public LiveData<List<Photo>> getAllPhotos() {
        return allPhotos;
    }
    
    /**
     * 获取照片分组的LiveData
     */
    public LiveData<List<PhotoGroup>> getPhotoGroups() {
        return photoGroups;
    }
    
    /**
     * 获取扫描进度的LiveData
     */
    public LiveData<Integer> getScanProgress() {
        return scanProgress;
    }
    
    /**
     * 获取是否正在扫描的LiveData
     */
    public LiveData<Boolean> getIsScanning() {
        return isScanning;
    }
    
    /**
     * 获取选中删除照片的总大小的LiveData
     */
    public LiveData<String> getTotalSelectedSize() {
        return totalSelectedSize;
    }
    
    /**
     * 获取选中删除照片的数量的LiveData
     */
    public LiveData<Integer> getTotalSelectedCount() {
        return totalSelectedCount;
    }
    
    /**
     * 获取缓存的扫描结果
     */
    public List<PhotoGroup> getCachedResults() {
        return resultsManager.getCachedResults();
    }
    
    /**
     * 检查是否有缓存的扫描结果
     */
    public boolean hasCachedResults() {
        return resultsManager.hasCachedResults();
    }
    
    @Override
    protected void onCleared() {
        super.onCleared();
        repository.release();
    }
}
