package com.example.photoduplicatecleaner.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.model.Photo;
import com.example.photoduplicatecleaner.model.PhotoGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * 照片组适配器，用于在结果列表屏幕中显示照片组
 */
public class PhotoGroupAdapter extends RecyclerView.Adapter<PhotoGroupAdapter.GroupViewHolder> {

    private List<PhotoGroup> photoGroups;
    private final OnGroupClickListener listener;

    public interface OnGroupClickListener {
        void onGroupClick(PhotoGroup group);
    }

    public PhotoGroupAdapter(OnGroupClickListener listener) {
        this.photoGroups = new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo_group, parent, false);
        return new GroupViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupViewHolder holder, int position) {
        PhotoGroup group = photoGroups.get(position);
        holder.bind(group);
    }

    @Override
    public int getItemCount() {
        return photoGroups.size();
    }

    public void setPhotoGroups(List<PhotoGroup> photoGroups) {
        this.photoGroups = photoGroups;
        notifyDataSetChanged();
    }

    class GroupViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvGroupInfo;
        private final TextView tvSelectionStatus;
        private final ImageView ivThumbnail;
        private final TextView tvDefaultKeep;

        GroupViewHolder(@NonNull View itemView) {
            super(itemView);
            tvGroupInfo = itemView.findViewById(R.id.tvGroupInfo);
            tvSelectionStatus = itemView.findViewById(R.id.tvSelectionStatus);
            ivThumbnail = itemView.findViewById(R.id.ivThumbnail);
            tvDefaultKeep = itemView.findViewById(R.id.tvDefaultKeep);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onGroupClick(photoGroups.get(position));
                }
            });
        }

        void bind(PhotoGroup group) {
            // 设置组信息
            String groupType = group.isDuplicate() ? "重复照片" : "相似照片";
            tvGroupInfo.setText(String.format("%s (%d张)", groupType, group.getPhotoCount()));

            // 设置选择状态
            int selectedCount = group.getSelectedCount();
            if (selectedCount > 0) {
                tvSelectionStatus.setText(String.format("已选择%d张，可释放%s", selectedCount, group.getFormattedSelectedSize()));
                tvSelectionStatus.setVisibility(View.VISIBLE);
            } else {
                tvSelectionStatus.setVisibility(View.GONE);
            }

            // 设置默认保留提示
            tvDefaultKeep.setText(R.string.default_keep_newest);
            tvDefaultKeep.setVisibility(View.VISIBLE);

            // 加载缩略图
            if (!group.getPhotos().isEmpty()) {
                Photo photo = group.getPhotos().get(0); // 显示第一张照片作为缩略图
                Glide.with(ivThumbnail.getContext())
                        .load(photo.getPath())
                        .placeholder(R.drawable.ic_image_placeholder)
                        .error(R.drawable.ic_image_error)
                        .centerCrop()
                        .into(ivThumbnail);
            }
        }
    }
}
