package com.example.photoduplicatecleaner;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.example.photoduplicatecleaner.ml.TFLiteModelManager;

/**
 * 应用程序类，用于初始化全局资源和配置
 */
public class PhotoDuplicateCleanerApp extends Application {
    private static final String TAG = "PhotoDuplicateCleanerApp";
    private static Context appContext;

    @Override
    public void onCreate() {
        super.onCreate();
        appContext = getApplicationContext();
        
        // 初始化TFLite模型
        initTFLiteModel();
        
        Log.d(TAG, "Application initialized");
    }

    /**
     * 初始化TensorFlow Lite模型
     */
    private void initTFLiteModel() {
        // 确保模型文件存在
        TFLiteModelManager.getInstance().ensureModelExists(this);
        
        // 预加载模型（可选，也可以在首次使用时加载）
        new Thread(() -> {
            boolean success = TFLiteModelManager.getInstance().loadModel(this);
            Log.d(TAG, "TFLite model preload " + (success ? "successful" : "failed"));
        }).start();
    }

    /**
     * 获取应用上下文
     */
    public static Context getAppContext() {
        return appContext;
    }
}
