package com.example.photoduplicatecleaner.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.photoduplicatecleaner.R;
import com.example.photoduplicatecleaner.adapter.PhotoGroupAdapter;
import com.example.photoduplicatecleaner.model.PhotoGroup;
import com.example.photoduplicatecleaner.viewmodel.MainViewModel;

import java.util.List;

/**
 * 结果列表屏幕，显示扫描结果并允许用户选择要删除的照片
 */
public class ResultsActivity extends AppCompatActivity implements PhotoGroupAdapter.OnGroupClickListener {

    private MainViewModel viewModel;
    private RecyclerView recyclerView;
    private PhotoGroupAdapter adapter;
    private TextView tvResultsTitle;
    private TextView tvTotalSpace;
    private TextView tvNoResults;
    private Button btnCleanSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        // 初始化视图
        recyclerView = findViewById(R.id.recyclerViewGroups);
        tvResultsTitle = findViewById(R.id.tvResultsTitle);
        tvTotalSpace = findViewById(R.id.tvTotalSpace);
        tvNoResults = findViewById(R.id.tvNoResults);
        btnCleanSelected = findViewById(R.id.btnCleanSelected);

        // 设置RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PhotoGroupAdapter(this);
        recyclerView.setAdapter(adapter);

        // 获取ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // 设置清理按钮点击监听器
        btnCleanSelected.setOnClickListener(v -> showDeleteConfirmationDialog());

        // 加载结果
        loadResults();

        // 观察选中照片的统计信息
        viewModel.getTotalSelectedCount().observe(this, count -> {
            btnCleanSelected.setEnabled(count > 0);
            updateTitle();
        });

        viewModel.getTotalSelectedSize().observe(this, size -> {
            tvTotalSpace.setText(getString(R.string.total_space, size));
        });
    }

    /**
     * 加载扫描结果
     */
    private void loadResults() {
        List<PhotoGroup> groups = viewModel.getCachedResults();
        if (groups.isEmpty()) {
            tvNoResults.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
            btnCleanSelected.setEnabled(false);
        } else {
            tvNoResults.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter.setPhotoGroups(groups);
            updateTitle();
        }
    }

    /**
     * 更新标题
     */
    private void updateTitle() {
        int groupCount = adapter.getItemCount();
        int selectedCount = viewModel.getTotalSelectedCount().getValue() != null ? viewModel.getTotalSelectedCount().getValue() : 0;
        tvResultsTitle.setText(getString(R.string.scan_results, groupCount));
        btnCleanSelected.setText(getString(R.string.clean_selected) + " (" + selectedCount + ")");
    }

    /**
     * 显示删除确认对话框
     */
    private void showDeleteConfirmationDialog() {
        int count = viewModel.getTotalSelectedCount().getValue() != null ? viewModel.getTotalSelectedCount().getValue() : 0;
        String size = viewModel.getTotalSelectedSize().getValue() != null ? viewModel.getTotalSelectedSize().getValue() : "0 B";

        if (count <= 0) {
            Toast.makeText(this, "请先选择要删除的照片", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.delete_confirmation);
        builder.setMessage(getString(R.string.delete_confirmation_message, count, size));
        builder.setPositiveButton(R.string.confirm, (dialog, which) -> deleteSelectedPhotos());
        builder.setNegativeButton(R.string.cancel, null);
        builder.show();
    }

    /**
     * 删除选中的照片
     */
    private void deleteSelectedPhotos() {
        int deletedCount = viewModel.deleteSelectedPhotos();
        if (deletedCount > 0) {
            Toast.makeText(this, "成功删除 " + deletedCount + " 张照片", Toast.LENGTH_SHORT).show();
            loadResults(); // 重新加载结果
        } else {
            Toast.makeText(this, "删除失败，请重试", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onGroupClick(PhotoGroup group) {
        // 跳转到分组详情页面
        Intent intent = new Intent(this, GroupDetailActivity.class);
        intent.putExtra("GROUP_ID", group.getId());
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.results_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_select_all) {
            viewModel.selectAllSuggestedInAllGroups();
            adapter.notifyDataSetChanged();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
