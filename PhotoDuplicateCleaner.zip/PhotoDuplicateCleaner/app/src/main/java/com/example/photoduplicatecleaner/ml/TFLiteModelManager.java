package com.example.photoduplicatecleaner.ml;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;

import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.common.FileUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.util.HashMap;
import java.util.Map;

import com.example.photoduplicatecleaner.util.ImageUtils;

/**
 * TensorFlow Lite模型管理器，负责加载模型和执行特征提取
 */
public class TFLiteModelManager {
    private static final String TAG = "TFLiteModelManager";
    private static final String MODEL_FILENAME = "mobilenet_v2_feature_extractor.tflite";
    private static final int IMAGE_SIZE = 224; // 模型输入图像尺寸
    
    private static TFLiteModelManager instance;
    private Interpreter tflite;
    private boolean isModelLoaded = false;
    
    private TFLiteModelManager() {
        // 私有构造函数，防止外部实例化
    }
    
    /**
     * 获取单例实例
     */
    public static synchronized TFLiteModelManager getInstance() {
        if (instance == null) {
            instance = new TFLiteModelManager();
        }
        return instance;
    }
    
    /**
     * 加载TensorFlow Lite模型
     * 
     * @param context 应用上下文
     * @return 是否成功加载模型
     */
    public boolean loadModel(Context context) {
        if (isModelLoaded) {
            return true;
        }
        
        try {
            // 从assets目录加载模型
            MappedByteBuffer modelBuffer = FileUtil.loadMappedFile(context, MODEL_FILENAME);
            
            // 创建Interpreter实例
            Interpreter.Options options = new Interpreter.Options();
            options.setNumThreads(4); // 使用4个线程进行推理
            tflite = new Interpreter(modelBuffer, options);
            
            isModelLoaded = true;
            Log.d(TAG, "TFLite model loaded successfully");
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Error loading TFLite model", e);
            return false;
        }
    }
    
    /**
     * 确保模型文件存在于assets目录，如果不存在则创建一个占位模型
     * 注意：这是为了演示，实际应用中应该提供真实的预训练模型
     * 
     * @param context 应用上下文
     */
    public void ensureModelExists(Context context) {
        try {
            // 检查模型是否已存在
            String[] assetList = context.getAssets().list("");
            boolean modelExists = false;
            for (String asset : assetList) {
                if (MODEL_FILENAME.equals(asset)) {
                    modelExists = true;
                    break;
                }
            }
            
            // 如果模型不存在，创建一个占位模型文件
            if (!modelExists) {
                Log.w(TAG, "Model file not found in assets, creating placeholder");
                File modelDir = context.getFilesDir();
                File modelFile = new File(modelDir, MODEL_FILENAME);
                
                try (FileOutputStream fos = new FileOutputStream(modelFile)) {
                    // 写入一些占位数据
                    byte[] placeholder = new byte[1024]; // 简单的占位数据
                    fos.write(placeholder);
                }
                
                // 将占位模型复制到assets目录（注意：实际上应用无法在运行时修改assets）
                // 这里只是演示，实际应用中应该在构建时包含真实模型
                Log.w(TAG, "Placeholder model created at: " + modelFile.getAbsolutePath());
            }
        } catch (IOException e) {
            Log.e(TAG, "Error ensuring model exists", e);
        }
    }
    
    /**
     * 提取图像的特征向量
     * 
     * @param bitmap 输入图像
     * @return 特征向量（浮点数组）
     */
    public float[] extractFeatures(Bitmap bitmap) {
        if (!isModelLoaded || tflite == null) {
            Log.e(TAG, "Model not loaded");
            return null;
        }
        
        try {
            // 预处理图像
            Bitmap preprocessedBitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_SIZE, IMAGE_SIZE, true);
            
            // 准备输入数据
            ByteBuffer inputBuffer = ByteBuffer.allocateDirect(1 * IMAGE_SIZE * IMAGE_SIZE * 3 * 4); // 1张图片，224x224，3通道，每个float 4字节
            inputBuffer.order(ByteOrder.nativeOrder());
            
            // 将图像数据填充到输入缓冲区
            int[] intValues = new int[IMAGE_SIZE * IMAGE_SIZE];
            preprocessedBitmap.getPixels(intValues, 0, preprocessedBitmap.getWidth(), 0, 0, 
                    preprocessedBitmap.getWidth(), preprocessedBitmap.getHeight());
            
            for (int i = 0; i < intValues.length; ++i) {
                int val = intValues[i];
                inputBuffer.putFloat(((val >> 16) & 0xFF) / 255.0f);
                inputBuffer.putFloat(((val >> 8) & 0xFF) / 255.0f);
                inputBuffer.putFloat((val & 0xFF) / 255.0f);
            }
            
            // 准备输出数据
            // 假设模型输出是1x1024的特征向量
            float[][] outputFeature = new float[1][1024];
            
            // 运行模型
            Map<Integer, Object> outputs = new HashMap<>();
            outputs.put(0, outputFeature);
            
            Object[] inputs = {inputBuffer};
            tflite.runForMultipleInputsOutputs(inputs, outputs);
            
            // 释放资源
            if (preprocessedBitmap != bitmap) {
                preprocessedBitmap.recycle();
            }
            
            return outputFeature[0];
        } catch (Exception e) {
            Log.e(TAG, "Error extracting features", e);
            return null;
        }
    }
    
    /**
     * 计算两个特征向量之间的余弦相似度
     * 
     * @param features1 特征向量1
     * @param features2 特征向量2
     * @return 余弦相似度，范围[-1,1]，值越大表示越相似
     */
    public static float cosineSimilarity(float[] features1, float[] features2) {
        if (features1 == null || features2 == null || features1.length != features2.length) {
            return -1.0f;
        }
        
        float dotProduct = 0.0f;
        float norm1 = 0.0f;
        float norm2 = 0.0f;
        
        for (int i = 0; i < features1.length; i++) {
            dotProduct += features1[i] * features2[i];
            norm1 += features1[i] * features1[i];
            norm2 += features2[i] * features2[i];
        }
        
        if (norm1 <= 0.0f || norm2 <= 0.0f) {
            return 0.0f;
        }
        
        return dotProduct / (float) (Math.sqrt(norm1) * Math.sqrt(norm2));
    }
    
    /**
     * 释放模型资源
     */
    public void close() {
        if (tflite != null) {
            tflite.close();
            tflite = null;
            isModelLoaded = false;
        }
    }
}
