package com.example.photoduplicatecleaner.model;

/**
 * 表示一张照片的实体类
 */
public class Photo {
    private String id;           // 唯一标识符
    private String path;         // 文件路径
    private long size;           // 文件大小（字节）
    private String displayName;  // 显示名称
    private long dateAdded;      // 添加日期（时间戳）
    private long dateModified;   // 修改日期（时间戳）
    private int width;           // 宽度（像素）
    private int height;          // 高度（像素）
    private float[] features;    // 特征向量

    public Photo(String id, String path, long size, String displayName, 
                 long dateAdded, long dateModified, int width, int height) {
        this.id = id;
        this.path = path;
        this.size = size;
        this.displayName = displayName;
        this.dateAdded = dateAdded;
        this.dateModified = dateModified;
        this.width = width;
        this.height = height;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public String getPath() {
        return path;
    }

    public long getSize() {
        return size;
    }

    public String getDisplayName() {
        return displayName;
    }

    public long getDateAdded() {
        return dateAdded;
    }

    public long getDateModified() {
        return dateModified;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public float[] getFeatures() {
        return features;
    }

    public void setFeatures(float[] features) {
        this.features = features;
    }

    /**
     * 获取照片的分辨率
     * @return 分辨率（宽x高）
     */
    public int getResolution() {
        return width * height;
    }

    /**
     * 获取格式化的文件大小
     * @return 格式化的文件大小字符串（如 "1.5 MB"）
     */
    public String getFormattedSize() {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", size / (1024.0 * 1024));
        } else {
            return String.format("%.1f GB", size / (1024.0 * 1024 * 1024));
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Photo photo = (Photo) o;
        return id.equals(photo.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
